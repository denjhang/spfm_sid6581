/*
 * This file is part of libsidplayfp, a SID player engine.
 *
 * Copyright 2011-2019 Leandro Nini <drfiemost@users.sourceforge.net>
 * Copyright 2007-2010 Antti Lankila
 * Copyright 2001 Simon White
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "residfp-emu.h"

#include <cmath>

#include "residfp/residfp.h"
#include "sidplayfp/siddefs.h"

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#define xstr(s) str(s)
#define str(s) #s

#define _VERSION(a,b,c) a ##.## b ##.## c
#define SID_VERSION(a,b,c) _VERSION(a,b,c)
#define LIBRESIDFP_VERSION \
    SID_VERSION(LIBRESIDFP_VERSION_MAJ, \
        LIBRESIDFP_VERSION_MIN, \
        LIBRESIDFP_VERSION_LEV)

namespace libsidplayfp
{

const char ERR_INVALID_CW[]     = "Invalid combined waveforms strength.";
const char ERR_INVALID_CAPS[]   = "Invalid caps type.";

const char* reSIDfpEmu::getCredits()
{
    return
        "reSIDfpEmu V" VERSION " Engine:\n"
        "\t(C) 1999-2002 Simon White\n"
        "libresidfp V" xstr(LIBRESIDFP_VERSION) ":\n"
        "\t(C) 1999-2002 Dag Lem\n"
        "\t(C) 2005-2011 Antti S. Lankila\n"
        "\t(C) 2010-2026 Leandro Nini\n";
}

reSIDfpEmu::reSIDfpEmu(sidbuilder *builder) :
    sidemu(builder),
    m_sid(*(new reSIDfp::residfp))
{
    reset(0);
}

reSIDfpEmu::~reSIDfpEmu()
{
    delete &m_sid;
    delete[] m_buffer;
}

// Standard component options
void reSIDfpEmu::reset(uint8_t volume)
{
    m_accessClk = 0;
    m_sid.reset();
    m_sid.write(0x18, volume);
}

uint8_t reSIDfpEmu::read(uint_least8_t addr)
{
    clock();
    return m_sid.read(addr);
}

void reSIDfpEmu::write(uint_least8_t addr, uint8_t data)
{
    clock();
    m_sid.write(addr, data);
}

void reSIDfpEmu::clock()
{
    const event_clock_t cycles = eventScheduler->getTime(EVENT_CLOCK_PHI1) - m_accessClk;
    m_accessClk += cycles;
    m_bufferpos += m_sid.clock(cycles, m_buffer+m_bufferpos);
}

void reSIDfpEmu::sampling(float systemclock, float freq,
        SidConfig::sampling_method_t method)
{
    reSIDfp::SamplingMethod sampleMethod;
    switch (method)
    {
    case SidConfig::INTERPOLATE:
        sampleMethod = reSIDfp::DECIMATE;
        break;
    case SidConfig::RESAMPLE_INTERPOLATE:
        sampleMethod = reSIDfp::RESAMPLE;
        break;
    default:
        m_status = false;
        m_error = ERR_INVALID_SAMPLING;
        return;
    }

    bool res = m_sid.setSamplingParameters(systemclock, sampleMethod, freq);
    if  (!res)
    {
        m_status = false;
        m_error = ERR_UNSUPPORTED_FREQ;
        return;
    }

    if (m_buffer)
        delete[] m_buffer;

    // 20ms buffer
    const int buffersize = std::ceil((freq / 1000.f) * 20.f);
    m_buffer = new short[buffersize];
    m_status = true;
}

// Set the emulated SID model
void reSIDfpEmu::model(SidConfig::sid_model_t model, bool digiboost)
{
    reSIDfp::ChipModel chipModel;
    switch (model)
    {
        case SidConfig::MOS6581:
            chipModel = reSIDfp::MOS6581;
            m_sid.input(0);
            break;
        case SidConfig::MOS8580:
            chipModel = reSIDfp::CSG8580;
            m_sid.input(digiboost ? -32768 : 0);
            break;
        default:
            m_status = false;
            m_error = ERR_INVALID_CHIP;
            return;
    }

    m_sid.setChipModel(chipModel);
    m_status = true;
}

// Set the emulated SID combined waveforms
void reSIDfpEmu::combinedWaveforms(SidConfig::sid_cw_t cws)
{
    reSIDfp::CombinedWaveforms combinedWaveforms;
    switch (cws)
    {
        case SidConfig::AVERAGE:
            combinedWaveforms = reSIDfp::AVERAGE;
            break;
        case SidConfig::WEAK:
            combinedWaveforms = reSIDfp::WEAK;
            break;
        case SidConfig::STRONG:
            combinedWaveforms = reSIDfp::STRONG;
            break;
        default:
            m_status = false;
            m_error = ERR_INVALID_CW;
            return;
    }

    m_sid.setCombinedWaveforms(combinedWaveforms);
    m_status = true;
}

// Set the emulated SID caps
void reSIDfpEmu::set6581caps(SidConfig::sid_caps_t caps)
{
#if (LIBRESIDFP_VERSION_MAJ > 1) || (LIBRESIDFP_VERSION_MIN > 2)
    reSIDfp::CapsType capsType;
    switch (caps)
    {
        case SidConfig::C2200PF:
            capsType = reSIDfp::CAPS2200;
            break;
        case SidConfig::C470PF:
            capsType = reSIDfp::CAPS470;
            break;
        case SidConfig::C330PF:
            capsType = reSIDfp::CAPS330;
            break;
        default:
            m_status = false;
            m_error = ERR_INVALID_CAPS;
            return;
    }

    m_sid.set6581caps(capsType);
    m_status = true;
#else
    bool enableOld;
    switch (caps)
    {
        case SidConfig::C2200PF:
            enableOld = true;
            break;
        case SidConfig::C470PF:
        case SidConfig::C330PF:
            enableOld = false;
            break;
        default:
            m_status = false;
            m_error = ERR_INVALID_CAPS;
            return;
    }

    m_sid.enableOld6581caps(enableOld);
    m_status = true;
#endif
}

}
